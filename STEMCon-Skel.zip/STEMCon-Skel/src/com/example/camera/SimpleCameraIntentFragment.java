package com.example.camera;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SimpleCameraIntentFragment extends Fragment implements Button.OnClickListener {
    public final String TAG = "SimpleCameraIntentFragment";

    static final int REQUEST_TAKE_PHOTO = 1;

    private ImageView mThumbnailImageView;

    public SimpleCameraIntentFragment(){
        super();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view =  null;
        // TODO
        //	Assign 'view' to the inflated layout for the fragment, using 'inflator'

        // TODO
        //	The fragment has two components: an ImageView and a Button
        //	Assign the class members for each of those components by using view.findViewById

        // TODO
        //	The button has an on click listener. Since this class implements Button.OnClickListener, you can assign its on-click listener to 'this'

        return view;
    }

    protected void takePhoto() {

    	// Checks to see if we have a camera (we should have one)
        Context context = getActivity();
        PackageManager packageManager = context.getPackageManager();
        if(packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA) == false){
            Toast.makeText(getActivity(), "This device does not have a camera.", Toast.LENGTH_SHORT)
                    .show();
            return;
        }

        // TODO
        //	Create a new MediaStore.ACTION_IMAGE_CAPTURE Intent
        Intent takePictureIntent = null;

        // Get the main activity
        MainActivity activity = (MainActivity)getActivity();
        if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {
        	// TODO
        	//	First create an image file using createImageFile
            File photoFile = null;
            
            if (photoFile != null) {
            	Uri fileUri = null;
            	// TODO
            	// 	Get the Uri of the file you created
            	
            	// TODO
            	//	Use the setter methods in the activity
            	
            	// TODO
            	//	put the photo URI in the intent as an extra
            	
            	// TODO
            	//	startActivityForResult
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_TAKE_PHOTO && resultCode == Activity.RESULT_OK) {
        	// TODO
        	//	add the photo to the gallery
        	
            MainActivity activity = (MainActivity)getActivity();

            // TODO
            //	Set the image to display in the image view
            
        } else {
        	// Use "Toast"s to display messages to the user when things go wrong
        	// Think of other places in the code where a Toast might be useful
            Toast.makeText(getActivity(), "Image Capture Failed", Toast.LENGTH_SHORT).show();
        }
    }

    protected File createImageFile() throws IOException {
    	// TODO
    	//	Create a temporary file name in the format "JPEG_<date>_.jpg"
    	//	The date should be in the format of "yyyyMMdd_HHmmss", eg. 20140514_093445"
    	//	An example file name could be: "JPEG_20140514_093445_.jpg"
    	//	use "Log.d(TAG, ...)" to write debugging messages out to logcat
    	//
    	//	Use static members within the "Environment" class to get the external storage public directory
    	File image = null;
    	
        MainActivity activity = (MainActivity)getActivity();
        
        // TODO
        //	Set the photo path within the activity
        
        return image;
    }

    protected void addPhotoToGallery() {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        MainActivity activity = (MainActivity)getActivity();
        File f = new File(activity.getPhotoPath());
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        this.getActivity().sendBroadcast(mediaScanIntent);
    }

    @Override
    public void onClick(View v) {
    	takePhoto();
    }

    /**
     * http://developer.android.com/training/camera/photobasics.html
     */
    private void setFullImageFromFilePath(String imagePath, ImageView imageView) {
        // Get the dimensions of the View
        int targetW = imageView.getWidth();
        int targetH = imageView.getHeight();

        // Get the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imagePath, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        // Determine how much to scale down the image
        int scaleFactor = Math.min(photoW/targetW, photoH/targetH);

        // Decode the image file into a Bitmap sized to fill the View
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inPurgeable = true;

        Bitmap bitmap = BitmapFactory.decodeFile(imagePath, bmOptions);
        Log.d(TAG, "Setting image bitmap");
        imageView.setImageBitmap(bitmap);
        Log.d(TAG, "Done setting bitmap");
    }
}
