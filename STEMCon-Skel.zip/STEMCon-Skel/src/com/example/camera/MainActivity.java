package com.example.camera;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


public class MainActivity extends Activity {

    private String mPhotoPath = null;
    private Uri mPhotoURI = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // TODO
        //	Set the content view, using the main activity's layout
    }

    public String getPhotoPath() {
        return mPhotoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.mPhotoPath = photoPath;
    }

    public Uri getPhotoURI() {
        return mPhotoURI;
    }

    public void setPhotoURI(Uri photoURI) {
        this.mPhotoURI = photoURI;
    }

}
